package com.ramsa.company.repository;

import com.ramsa.company.entity.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Search for employees by name with pagination
    Page<Employee> findByNameContainingIgnoreCase(String name, Pageable pageable);

    // Search for employees by department ID with pagination
    Page<Employee> findByDepartmentId(Long departmentId, Pageable pageable);
}
