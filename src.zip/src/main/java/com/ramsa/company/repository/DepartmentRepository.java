package com.ramsa.company.repository;


import com.ramsa.company.entity.Department;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Search for departments by name with pagination
    Page<Department> findByNameContainingIgnoreCase(String name, Pageable pageable);
}
