package com.ramsa.company.service;

import com.ramsa.company.advice.ResourceNotFoundException;
import com.ramsa.company.dto.DepartmentDTO;
import com.ramsa.company.entity.Department;
import com.ramsa.company.repository.DepartmentRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DepartmentService {
    @Autowired
    private final DepartmentRepository departmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    // Create a new department
    public DepartmentDTO createDepartment(@Valid DepartmentDTO departmentDTO) {
        Department department = new Department();
        department.setName(departmentDTO.getName());
        Department savedDepartment = departmentRepository.save(department);
        return convertToDTO(savedDepartment);
    }

    // Read all departments
    public List<DepartmentDTO> getAllDepartments() {
        return departmentRepository.findAll()
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // Read a department by ID
    public Optional<DepartmentDTO> getDepartmentById(Long id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department with ID " + id + " not found"));
        return Optional.of(convertToDTO(department));
    }

    // Update a department
    public Optional<DepartmentDTO> updateDepartment(Long id,@Valid DepartmentDTO departmentDTO) {
        return departmentRepository.findById(id).map(department -> {
            department.setName(departmentDTO.getName());
            Department updatedDepartment = departmentRepository.save(department);
            return convertToDTO(updatedDepartment);
        });
    }

    // Delete a department
    public void deleteDepartment(Long id) {
        departmentRepository.deleteById(id);
    }

    // Search departments by name
    public Page<DepartmentDTO> searchDepartments(String name, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return departmentRepository.findByNameContainingIgnoreCase(name, pageable)
                .map(department -> convertToDTO(department));
    }

    // Convert Department to DepartmentDTO
    private DepartmentDTO convertToDTO(Department department) {
        return new DepartmentDTO(department.getId(), department.getName());
    }


}
