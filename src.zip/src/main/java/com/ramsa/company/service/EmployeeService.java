package com.ramsa.company.service;

import com.ramsa.company.advice.ResourceNotFoundException;
import com.ramsa.company.dto.EmployeeDTO;
import com.ramsa.company.entity.Department;
import com.ramsa.company.entity.Employee;
import com.ramsa.company.repository.EmployeeRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    @Autowired
    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // Create a new employee
    public EmployeeDTO createEmployee(@Valid EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        employee.setName(employeeDTO.getName());
        employee.setSalary(employeeDTO.getSalary());
        // Set department if needed, you can fetch department by ID
        employee.setDepartment(new Department(employeeDTO.getDepartmentId()));
        Employee savedEmployee = employeeRepository.save(employee);
        return convertToDTO(savedEmployee);
    }

    // Read all employees
    public List<EmployeeDTO> getAllEmployees() {
        return employeeRepository.findAll()
                .stream()
                .map(employee -> convertToDTO(employee))
                .collect(Collectors.toList());
    }

    // Read an employee by ID
    public Optional<EmployeeDTO> getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee with ID " + id + " not found"));
        return Optional.of(convertToDTO(employee));
    }

    // Update an employee
    public Optional<EmployeeDTO> updateEmployee(Long id,@Valid EmployeeDTO employeeDTO) {
        return employeeRepository.findById(id).map(employee -> {
            employee.setName(employeeDTO.getName());
            employee.setSalary(employeeDTO.getSalary());
            employee.setDepartment(new Department(employeeDTO.getDepartmentId()));
            Employee updatedEmployee = employeeRepository.save(employee);
            return convertToDTO(updatedEmployee);
        });
    }

    // Delete an employee
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    // Search employees by name
    public Page<EmployeeDTO> searchEmployees(String name, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return employeeRepository.findByNameContainingIgnoreCase(name, pageable)
                .map(employee -> convertToDTO(employee));
    }

    // Get employees by department
    public Page<EmployeeDTO> getEmployeesByDepartment(Long departmentId, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return employeeRepository.findByDepartmentId(departmentId, pageable)
                .map(employee -> convertToDTO(employee));
    }

    // Convert Employee to EmployeeDTO
    private EmployeeDTO convertToDTO(Employee employee) {
        return new EmployeeDTO(
                employee.getId(),
                employee.getName(),
                employee.getSalary(),
                employee.getDepartment() != null ? employee.getDepartment().getId() : null
        );
    }
}
